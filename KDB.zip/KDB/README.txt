1.run npm init at terminal in one of your new folder
2.unzip and put these conetent into the new folder
3.run npm start at terminal in the new folder
4.open browser and type localhost:8080 