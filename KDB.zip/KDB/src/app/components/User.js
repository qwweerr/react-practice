import React from "react";


export class User extends React.Component {
    onNavigateHome() {
            this.props.history.push("/");
    }
    render() {
        return (
            <div>
                <h3>The User Page</h3>
                <p></p>  
                <button onClick={this.onNavigateHome.bind(this)}>GO Back</button> 
            </div>
        );
    }
}