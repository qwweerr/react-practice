import React from "react";

export class Question extends React.Component {
	onNavigateHome() {
            this.props.history.push("/");
    }
    render() {
        return (
            <div>
                <h3>Question</h3>
                <p>Prove 1 + 1 = 2</p>
                <button onClick={this.onNavigateHome.bind(this)}>GO Back</button> 
            </div>
        );
    }
}