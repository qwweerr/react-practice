import React from "react";
import {NavLink } from "react-router-dom";

export class Header extends React.Component {
    render(){
        return (
            <div className="navbar">
                <NavLink to={"/"}>Home</NavLink>
                <div className="dropdown">
                    <button className="dropbtn">
                        Dropdown1    
                    </button>
                    <div className="dropdown-content">
                        <NavLink to={"/question"}>Question</NavLink>
                        <NavLink to={"/user"}>User</NavLink>
                    </div>
                </div> 
                <div className="dropdown">
                    <button className="dropbtn">
                        Dropdown2     
                    </button>
                    <div className="dropdown-content">
                        <NavLink to={"/question"}>Question</NavLink>
                        <NavLink to={"/user"}>User</NavLink>
                    </div>
                </div> 
            </div>
        );
    }
};