import React from "react";
import {render} from "react-dom";
import { Switch, BrowserRouter, Route, IndexRouter } from "react-router-dom";


import {Home} from "./components/Home";
import {Question} from "./components/Question";
import {User} from "./components/User";

class App extends React.Component {
    render() {
        return (
             	<BrowserRouter>
             			<Home>
             			<Route path="/user" component={User}/>
               		<Route path="/question" component={Question}/>
               	  </Home>
               	</BrowserRouter>
            		
        );
    }
}

render(<App />, window.document.getElementById('app'));